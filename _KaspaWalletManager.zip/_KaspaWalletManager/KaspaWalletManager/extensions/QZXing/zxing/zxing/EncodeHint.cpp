#include "EncodeHint.h"

namespace zxing {

EncodeHint::EncodeHint() :
    errorCorrectionLevel_(NULL), characterSet_(""), margin_(0)
{}

}
