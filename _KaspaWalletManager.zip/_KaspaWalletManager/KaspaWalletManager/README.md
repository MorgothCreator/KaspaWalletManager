# LyraWalletManager
 Lyra Block Lattice unified UI wallet for all OS platforms

Linux support:

* Ubuntu 19

* Linux Mint 20

* LUbuntu 20

MacOS support:

* Apple silicon.

Windows support:

* Windows 8, even if is showing an error that MSVCR100.dll missing.

* Windows 10.

Android support:

* 7.0 and up.

iOS support:

* Build done, need to be signed.
