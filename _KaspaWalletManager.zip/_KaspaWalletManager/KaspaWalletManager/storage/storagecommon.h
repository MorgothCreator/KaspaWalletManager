#ifndef STORAGECOMMON_H
#define STORAGECOMMON_H


class StorageCommon
{
public:
    static void makeWalletFolder();
    static void makeSettingsFolder();
};

#endif // STORAGECOMMON_H
